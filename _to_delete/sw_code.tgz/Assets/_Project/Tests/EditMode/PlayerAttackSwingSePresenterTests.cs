using System.Collections.Generic;
using Momotaro.Gameplay.Combat;
using Momotaro.Presentation.Combat;
using NUnit.Framework;
using UnityEngine;

namespace Momotaro.Tests.EditMode
{
    /// <summary>
    /// P3.5-08C：<see cref="PlayerAttackSwingSePresenter"/> が判定（Active）区間の立ち上がりで段別スイング SE を 1 回鳴らし、
    /// Active 継続中は再発火せず、段ごとに正しい鍵を鳴らし、敵段・非攻撃では鳴らさず、SE 未割当でも無例外なことを検証する。
    /// </summary>
    public sealed class PlayerAttackSwingSePresenterTests
    {
        private readonly List<Object> _spawned = new List<Object>();

        private sealed class FakeSwing : IAttackSwingSource
        {
            public bool IsSwingHitboxActive { get; set; }
            public int SwingStage { get; set; }
            public Vector3 SwingCenter => Vector3.zero;
            public Vector3 SwingHalfExtents => Vector3.zero;
            public Vector3 SwingForward => Vector3.forward;
        }

        [TearDown]
        public void TearDown()
        {
            foreach (Object o in _spawned)
            {
                if (o != null) Object.DestroyImmediate(o);
            }

            _spawned.Clear();
        }

        private PlayerAttackSwingSePresenter NewPresenter(out FakeSwing src, out CombatSePlayer se, bool withSe = true)
        {
            var go = new GameObject("SwingSe");
            _spawned.Add(go);
            var p = go.AddComponent<PlayerAttackSwingSePresenter>();

            se = null;
            if (withSe)
            {
                var seGo = new GameObject("CombatSePlayer");
                _spawned.Add(seGo);
                se = seGo.AddComponent<CombatSePlayer>();
                p.Se = se;
            }

            src = new FakeSwing();
            p.Bind(src);
            return p;
        }

        [Test]
        public void RisingEdge_PlaysStage1Se_Once()
        {
            PlayerAttackSwingSePresenter p = NewPresenter(out FakeSwing src, out CombatSePlayer se);

            src.SwingStage = 1;
            src.IsSwingHitboxActive = false;
            p.Tick();
            Assert.AreEqual(0, p.SwingCount, "Active 前は鳴らさない。");

            src.IsSwingHitboxActive = true;
            p.Tick();
            Assert.AreEqual(1, p.SwingCount, "Active 立ち上がりで 1 回鳴る。");
            Assert.AreEqual("SE_Player_Attack1", p.LastSwingSeId);
            Assert.AreEqual("SE_Player_Attack1", se.LastRequestedSeId);

            // Active 継続中は再発火しない（振り 1 回につき 1 音）。
            p.Tick();
            p.Tick();
            Assert.AreEqual(1, p.SwingCount, "Active 継続では再発火しない。");
        }

        [Test]
        public void FallingThenRising_FiresAgain_WithNextStage()
        {
            PlayerAttackSwingSePresenter p = NewPresenter(out FakeSwing src, out CombatSePlayer se);

            src.SwingStage = 1;
            src.IsSwingHitboxActive = true;
            p.Tick(); // 1 段目発火。
            src.IsSwingHitboxActive = false;
            p.Tick(); // 立ち下がり。

            src.SwingStage = 2;
            src.IsSwingHitboxActive = true;
            p.Tick(); // 2 段目発火。

            Assert.AreEqual(2, p.SwingCount);
            Assert.AreEqual("SE_Player_Attack2", p.LastSwingSeId);
            Assert.AreEqual("SE_Player_Attack2", se.LastRequestedSeId);
        }

        [Test]
        public void Stage3_And_Special_PlayTheirSe()
        {
            PlayerAttackSwingSePresenter p = NewPresenter(out FakeSwing src, out CombatSePlayer se);

            src.SwingStage = 3;
            src.IsSwingHitboxActive = true;
            p.Tick();
            Assert.AreEqual("SE_Player_Attack3", p.LastSwingSeId);

            src.IsSwingHitboxActive = false;
            p.Tick();
            src.SwingStage = AttackSwing.SpecialStage;
            src.IsSwingHitboxActive = true;
            p.Tick();
            Assert.AreEqual("SE_Player_Special", p.LastSwingSeId);
            Assert.AreEqual(2, p.SwingCount);
        }

        [Test]
        public void EnemyStage_And_NonAttack_DoNotFire()
        {
            PlayerAttackSwingSePresenter p = NewPresenter(out FakeSwing src, out CombatSePlayer se);

            src.SwingStage = AttackSwing.EnemyMeleeNormal; // 敵段は主人公スイング SE の対象外。
            src.IsSwingHitboxActive = true;
            p.Tick();
            Assert.AreEqual(0, p.SwingCount, "敵段では鳴らさない。");

            src.IsSwingHitboxActive = false;
            p.Tick();
            src.SwingStage = 0; // 非攻撃。
            src.IsSwingHitboxActive = true;
            p.Tick();
            Assert.AreEqual(0, p.SwingCount, "非攻撃(0)では鳴らさない。");
        }

        [Test]
        public void NoSePlayer_NoException_StillCountsEdge()
        {
            PlayerAttackSwingSePresenter p = NewPresenter(out FakeSwing src, out CombatSePlayer se, withSe: false);

            src.SwingStage = 1;
            src.IsSwingHitboxActive = true;
            Assert.DoesNotThrow(() => p.Tick(), "SE 再生器未割当でも無例外。");
            Assert.AreEqual(1, p.SwingCount);
            Assert.AreEqual("SE_Player_Attack1", p.LastSwingSeId);
        }
    }
}
